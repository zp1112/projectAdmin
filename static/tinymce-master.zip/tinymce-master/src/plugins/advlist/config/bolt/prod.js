configure({
  configs: [
    '../../../../../config/bolt/prod.plugin.js'
  ]
});
