export default {
    switchLangTitle: '切換語言'
};
