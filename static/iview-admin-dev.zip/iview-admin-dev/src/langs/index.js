import enLang from './en';
import zhLang from './zh';
import zhTradLang from './zh_trad';

export const en = enLang;
export const zh = zhLang;
export const zhT = zhTradLang;
